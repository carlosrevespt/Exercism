package allergies.exercism;

import allergies.exercism.Allergen;
import allergies.exercism.AllergenComparator;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.lang.Math;

class Allergies {
	
	private List<Allergen> allergenList = new ArrayList<Allergen>();
	
	Allergies (int totalScore){
		int power;
		int allergenScore;
		
		while (totalScore > 0) {
			power = log2(totalScore);
			allergenScore = (int) Math.pow(2, power);
			if (power < 8) {
				allergenList.add(Allergen.valueOf(allergenScore));				
			}
			totalScore -= allergenScore;
		}
		Collections.sort(allergenList, new AllergenComparator());
	}
	
	boolean isAllergicTo(Allergen myAllergen) {
		return allergenList.contains(myAllergen);
	}
	
	List<Allergen> getList(){
		return allergenList;
	}
	
	private int log2(int value) {
		return (int) (Math.log(value) / Math.log(2));
	}
}
